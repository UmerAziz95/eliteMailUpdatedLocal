<footer class="text-center p-3 mt-4 rounded-3">
    <p class="mb-0">&copy; {{ date('Y') }} Laravel App. All rights reserved.</p>
</footer>
