<div class="table-responsive">
    <table class="display w-100" id="<?php echo e(isset($plan_id) ? 'myTable-'.$plan_id : 'myTable'); ?>">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Date</th>
                <?php if(!isset($plan_id)): ?>
                <th>Plan</th>
                <?php endif; ?>
                <th>Customer Email</th>
                <th>Domain URL</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div><?php /**PATH D:\projectinbox_backup-main\projectinbox_backup-main\resources\views/customer/orders/_orders_table.blade.php ENDPATH**/ ?>