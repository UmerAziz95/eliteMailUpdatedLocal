

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($plan->name); ?> - Plan Details</div>

                <div class="card-body">
                    <div class="text-center mb-4">
                        <h2 class="mb-3">$<?php echo e(number_format($plan->price, 2)); ?> <span class="fs-6">/<?php echo e($plan->duration); ?></span></h2>
                        <p class="mb-3"><?php echo e($plan->description); ?></p>
                        <div class="mb-3"><?php echo e($plan->min_inbox); ?><?php echo e($plan->max_inbox == 0 ? '+' : ' - ' . $plan->max_inbox); ?> <strong>Inboxes</strong></div>
                    </div>

                    <div class="features-list">
                        <?php if($plan->features->count() > 0): ?>
                            <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="feature-item mb-2">
                                    <i class="fas fa-check text-success"></i>
                                    <?php echo e($feature->title); ?>

                                    <?php if($feature->pivot->value): ?>
                                        <?php echo e($feature->pivot->value); ?>

                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-muted text-center">No additional features</p>
                        <?php endif; ?>
                    </div>

                    <div class="text-center mt-4">
                        <button class="btn btn-primary subscribe-btn" data-plan-id="<?php echo e($plan->id); ?>">
                            Subscribe Now
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('.subscribe-btn').click(function() {
        const planId = $(this).data('plan-id');
        
        $.ajax({
            url: `/customer/plans/${planId}/subscribe`,
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = response.redirect_url;
                } else {
                    showErrorToast(response.message || 'Failed to initiate subscription');
                }
            },
            error: function(xhr) {
                showErrorToast(xhr.responseJSON?.message || 'Failed to initiate subscription');
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projectinbox_backup-main\projectinbox_backup-main\resources\views\customer\pricing\plan-details.blade.php ENDPATH**/ ?>