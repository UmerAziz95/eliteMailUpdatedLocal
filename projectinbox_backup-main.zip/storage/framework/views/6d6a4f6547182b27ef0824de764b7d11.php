<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h2 class="text-center mb-4">Choose Your Plan</h2>
            <div class="row">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center">
                            <h3><?php echo e($plan->name); ?></h3>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="text-center mb-4">
                                <h2 class="mb-3">$<?php echo e(number_format($plan->price, 2)); ?> <span class="fs-6">/<?php echo e($plan->duration); ?></span></h2>
                                <p class="mb-3"><?php echo e($plan->description); ?></p>
                                <div class="mb-3"><?php echo e($plan->min_inbox); ?><?php echo e($plan->max_inbox == 0 ? '+' : ' - ' . $plan->max_inbox); ?> <strong>Inboxes</strong></div>
                            </div>

                            <div class="features-list flex-grow-1">
                                <?php if($plan->features->count() > 0): ?>
                                    <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="feature-item mb-2">
                                            <i class="fas fa-check text-success"></i>
                                            <?php echo e($feature->title); ?>

                                            <?php if($feature->pivot->value): ?>
                                                <?php echo e($feature->pivot->value); ?>

                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p class="text-muted text-center">No additional features</p>
                                <?php endif; ?>
                            </div>

                            <div class="text-center mt-4">
                                <?php
                                    $activeSubscription = auth()->user()->subscription()
                                        ->where('plan_id', $plan->id)
                                        ->where('status', 'active')
                                        ->first();
                                ?>
                                <?php if($activeSubscription): ?>
                                    <button class="btn btn-success" disabled>
                                        <i class="fas fa-check me-2"></i>Subscribed Plan
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-primary subscribe-btn" data-plan-id="<?php echo e($plan->id); ?>">
                                        Subscribe Now
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('.subscribe-btn').click(function() {
        const planId = $(this).data('plan-id');
        // reload to new order page
        window.location.href = `/customer/orders/new-order/${planId}`;
        // $.ajax({
        //     url: `/customer/plans/${planId}/subscribe`,
        //     type: 'POST',
        //     data: {
        //         _token: '<?php echo e(csrf_token()); ?>'
        //     },
        //     success: function(response) {
        //         if (response.success) {
        //             // Redirect to Chargebee hosted page
        //             window.location.href = response.hosted_page_url;
        //         } else {
        //             // Show error message
        //             alert(response.message || 'Failed to initiate subscription');
        //         }
        //     },
        //     error: function(xhr) {
        //         alert(xhr.responseJSON?.message || 'Failed to initiate subscription');
        //     }
        // });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projectinbox_backup-main\projectinbox_backup-main\resources\views/customer/pricing/pricing.blade.php ENDPATH**/ ?>